package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
  private EntryPair[] array; //load this array
  private int size = 0;
  private static final int arraySize = 10000; //Everything in the array will initially 
                                              //be null. This is ok! Just build out 
                                              //from array[1]

  public MinBinHeap() {
    this.array = new EntryPair[arraySize];
    array[0] = new EntryPair(null, -100000); //0th will be unused for simplicity 
                                             //of child/parent computations...
                                             //the book/animation page both do this.
  }
    
  //Please do not remove or modify this method! Used to test your entire Heap.
  @Override
  public EntryPair[] getHeap() { 
    return this.array;
  }

@Override
public void insert(EntryPair entry) {
  	size++;
  	int i;
  	for (i = size; i > 1 && entry.getPriority() < array[i/2].getPriority(); i = i/2){
  		array[i] = array[i/2];// i is the current node spot; i/2 is the parent node
  	} 		
  	array[i] = entry;
}

@Override
public void delMin() {
	if (size == 0){
		return;
	}
	array[1] = array[size];
	array[size] = null;
	size--;
	bubbleDown(1);
	
	
}

public void bubbleDown(int i){
	int child;
	EntryPair entry = array[i];
	
	for (; i*2 <= size(); i = child){
		child = i*2;
		if (child != size() && array[child].getPriority() > array[child+1].getPriority()){
			child++;
		}
		if (entry.getPriority() > array[child].getPriority()){
		    entry = array[i];
			array[i] = array[child];
			array[child] = entry;
		}
		else {break;}
	}
}


@Override
public EntryPair getMin() {
	if (size == 0) {
		return null;
	}
	else {return array[1];}
}

@Override
public int size() {
	return size;
	
}

@Override
public void build(EntryPair[] entries) {
	int i;
	int k;
	
	for (i=0; i<entries.length; i++){
		array[i+1] = entries[i];
		size++;
	}
	int parentIndex = size()/2;
	for (k = parentIndex; k >= 1; k--){
		bubbleDown(k);
	}
}
}
